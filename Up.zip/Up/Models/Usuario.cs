namespace Up.Models;

public class Usuario
{
    public int Cod{get;set;}

}
