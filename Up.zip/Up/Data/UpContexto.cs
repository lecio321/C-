using Microsoft.EntityFrameworkCore;
using Up.Models;

namespace Up.Data;

public class UpContexto: DbContext
{
      public UpContexto(DbContextOptions<UpContexto> options) : base(options)
    {
    }

    //Criar os DBSet para representar cada tabela do banco de dados
    public DbSet<Usuario> Usuarios { get; set; }

}
